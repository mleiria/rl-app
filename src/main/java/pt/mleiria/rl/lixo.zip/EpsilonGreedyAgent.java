package pt.mleiria.rl;

import java.util.Arrays;
import java.util.Random;
/**
 * A simple Epsilon-Greedy agent for the multi-armed bandit problem.
 */
public class EpsilonGreedyAgent implements Agent {
    private final int numArms;
    private final double epsilon;
    private final double[] qEstimates; // Estimated action values (Q(a))
    private final int[] actionCounts; // Number of times each action has been taken
    private final Random random;

    public EpsilonGreedyAgent(int numArms, double epsilon) {
        this.numArms = numArms;
        this.epsilon = epsilon;
        this.qEstimates = new double[numArms];
        this.actionCounts = new int[numArms];
        this.random = new Random();

        // Initialize estimates to 0. This is pessimistic, but common.
        // For optimistic initial values, you'd initialize them to a high value.
        Arrays.fill(qEstimates, 0.0);
        Arrays.fill(actionCounts, 0);
    }
    public EpsilonGreedyAgent(int numArms, double epsilon, double initialQ) {
        this.numArms = numArms;
        this.epsilon = epsilon;
        this.qEstimates = new double[numArms];
        this.actionCounts = new int[numArms];
        this.random = new Random();

        // Initialize estimates to 0. This is pessimistic, but common.
        // For optimistic initial values, you'd initialize them to a high value.
        Arrays.fill(qEstimates, initialQ);
        Arrays.fill(actionCounts, 0);
    }

    /**
     * Chooses an action based on the epsilon-greedy strategy.
     * With probability epsilon, a random arm is chosen (exploration).
     * Otherwise (1-epsilon probability), the arm with the highest estimated value is chosen (exploitation).
     *
     * @return The index of the chosen arm.
     */
    @Override
    public int chooseAction() {
        if (random.nextDouble() < epsilon) {
            // Explore: choose a random arm
            return random.nextInt(numArms);
        } else {
            // Exploit: choose the arm with the highest estimated value
            return getBestAction();
        }
    }

    /**
     * Updates the estimated value of the chosen arm after receiving a reward.
     * Uses the sample-average method: Q(a) = (sum of rewards for a) / (number of times a taken)
     * This is implemented incrementally to avoid storing all rewards.
     *
     * @param chosenArm The index of the arm that was pulled.
     * @param reward    The reward received from pulling that arm.
     */
    @Override
    public void updateEstimates(int chosenArm, double reward) {
        actionCounts[chosenArm]++;
        // Incremental update rule: Q_new = Q_old + (1/N) * (Reward - Q_old)
        qEstimates[chosenArm] += (1.0 / actionCounts[chosenArm]) * (reward - qEstimates[chosenArm]);
    }

    /**
     * Finds the index of the arm with the current highest estimated value.
     * In case of ties, one of the tied actions is chosen randomly.
     *
     * @return The index of the best estimated arm.
     */
    private int getBestAction() {
        double maxQ = qEstimates[0];
        // Collect all indices that have the maxQ (to handle ties randomly)
        java.util.List<Integer> bestActions = new java.util.ArrayList<>();
        bestActions.add(0);

        for (int i = 1; i < numArms; i++) {
            if (qEstimates[i] > maxQ) {
                maxQ = qEstimates[i];
                bestActions.clear(); // New max found, clear previous
                bestActions.add(i);
            } else if (qEstimates[i] == maxQ) {
                bestActions.add(i); // Tie
            }
        }

        // Return a random choice from the best actions if there's a tie
        return bestActions.get(random.nextInt(bestActions.size()));
    }
}
