package pt.mleiria.rl;

import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import pt.mleiria.dto.Pair;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class Main {

    private static final int numArms = 10;
    private static final int numSteps = 1000; // Number of pulls/time steps per run
    private static final int numRuns = 2000; // Number of independent bandit problems/runs

    // --- Example Usage with an Epsilon-Greedy Agent ---
    public static void main(String[] args) throws IOException {


        final List<Double> epsilonList = List.of(0.1, 0.01, 0.0);
        final List<Pair<double[], Double>> averageRewardsDataList = new ArrayList<>();
        final List<Pair<double[], Double>> optimalActionPercentagesDataList = new ArrayList<>();

        epsilonList.forEach(epsilon -> {
            final Pair<double[], double[]> run = testBedRun(epsilon);
            // Arrays to store results averaged over all runs
            final double[] averageRewards = run._1();
            final double[] optimalActionPercentages = run._2();
            averageRewardsDataList.add(new Pair<>(averageRewards, epsilon));
            optimalActionPercentagesDataList.add(new Pair<>(optimalActionPercentages, epsilon));
        });

        // Build the chart
        List<XYSeries> seriesList = new ArrayList<>();
        averageRewardsDataList.forEach(average -> {
            XYSeries series = new XYSeries("epsilon: "  + average._2());
            IntStream.range(0, average._1().length).forEach(i -> {
                series.add(i, average._1()[i]);
            });
            seriesList.add(series);
        });
        JFreeChart chart =
        LineChart.LineChartBuilder
                .aLineChart()
                .withSeries(seriesList)
                .withXLabel("Steps")
                .withYLabel("Average rewards")
                .withTitle("Epsilon variation")
                .build()
                .createDataset();
        File outputFile = new File("chart.png");
        ChartUtils.saveChartAsPNG(outputFile, chart, 500, 400);

        System.out.println("Chart saved to " + outputFile.getAbsolutePath());

    }

    private static Pair<double[], double[]> testBedRun(final double epsilon) {
        // Arrays to store results averaged over all runs
        final double[] averageRewards = new double[numSteps];
        final double[] optimalActionPercentages = new double[numSteps];
        for (int run = 0; run < numRuns; run++) {
            TenArmTestbed testbed = new TenArmTestbed(numArms);
            Agent agent = new EpsilonGreedyAgent(numArms, epsilon);

            for (int step = 0; step < numSteps; step++) {
                // Chooses to exploit or explore
                int chosenArm = agent.chooseAction();
                // Gets the reward given by the chossen arm
                double reward = testbed.pullArm(chosenArm);
                agent.updateEstimates(chosenArm, reward);

                // Accumulate rewards for averaging
                averageRewards[step] += reward;

                // Check if the chosen arm was the optimal one for this specific testbed
                if (chosenArm == testbed.getOptimalArmIndex()) {
                    optimalActionPercentages[step] += 1;
                }
            }
        }
        // Average the results over all runs
        System.out.println("--- Simulation Results ---");
        System.out.println("Epsilon: " + epsilon);
        System.out.println("Number of Runs: " + numRuns);
        System.out.println("Number of Steps per Run: " + numSteps);
        System.out.println("--------------------------");

        for (int step = 0; step < numSteps; step++) {
            averageRewards[step] /= numRuns;
            optimalActionPercentages[step] = (optimalActionPercentages[step] / numRuns) * 100; // Convert to percentage
            // You can print or store these results for plotting
            // For brevity, we'll just print a few points
            if (step % (numSteps / 10) == 0 || step == numSteps - 1) {
                System.out.printf("Step %4d: Avg Reward = %.4f, Optimal Action %% = %.2f%%\n",
                        step + 1, averageRewards[step], optimalActionPercentages[step]);
            }
        }
        System.out.println("\nSimulation complete. You can use 'averageRewards' and 'optimalActionPercentages' arrays for plotting.");
        return new Pair<>(averageRewards, optimalActionPercentages);
    }

    private static void plotAvgRewards(final double[] averageRewards) {
        XYSeries series1 = new XYSeries("Average Rewards");
        for (int step = 0; step < averageRewards.length; step++) {
            series1.add(step + 1, averageRewards[step]);
        }

        SwingUtilities.invokeLater(() -> {
            MultipleLineChart multipleLineChart = new MultipleLineChart(List.of(series1));
            multipleLineChart.setSize(800, 600);
            multipleLineChart.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            multipleLineChart.setVisible(true);
        });
    }
}
