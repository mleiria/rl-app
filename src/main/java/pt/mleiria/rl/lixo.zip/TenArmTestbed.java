package pt.mleiria.rl;

import java.util.Arrays;
import java.util.Random;
import java.util.logging.Logger;
import java.util.stream.IntStream;

public class TenArmTestbed {

    private static final Logger LOG = Logger.getLogger(TenArmTestbed.class.getName());

    private final int numArms;
    private final double[] trueActionValues; // q*(a)
    private final Random random;

    /**
     * Initializes a TenArmTestbed with a specified number of arms.
     * The true action values for each arm are drawn from a standard normal distribution (mean 0, variance 1).
     */
    public TenArmTestbed(int numArms) {
        this.numArms = numArms;
        this.trueActionValues = new double[numArms];
        this.random = new Random();

        // Generate true action values for each arm from a standard normal distribution
        for (int i = 0; i < numArms; i++) {
            trueActionValues[i] = random.nextGaussian(); // mean 0, std dev 1
        }
    }

    /**
     * Simulates pulling an arm and returns a reward.
     * The reward is drawn from a normal distribution with mean q*(armIndex) and variance 1.
     *
     * @param armIndex The index of the arm to pull (0 to numArms-1).
     * @return The reward received.
     * @throws IllegalArgumentException if armIndex is out of bounds.
     */
    public double pullArm(int armIndex) {
        if (armIndex < 0 || armIndex >= numArms) {
            throw new IllegalArgumentException("Arm index out of bounds: " + armIndex);
        }
        // Reward is drawn from a normal distribution with mean trueActionValues[armIndex] and variance 1
        return trueActionValues[armIndex] + random.nextGaussian();
    }

    /**
     * Returns the true action value of a specific arm.
     *
     * @param armIndex The index of the arm.
     * @return The true average reward for that arm.
     */
    public double getTrueActionValue(int armIndex) {
        if (armIndex < 0 || armIndex >= numArms) {
            throw new IllegalArgumentException("Arm index out of bounds: " + armIndex);
        }
        return trueActionValues[armIndex];
    }

    /**
     * Finds the index of the optimal arm (the one with the highest true action value).
     *
     * @return The index of the optimal arm.
     */
    public int getOptimalArmIndex() {
        int optimalArm = 0;
        double maxTrueValue = trueActionValues[0];
        for (int i = 1; i < numArms; i++) {
            if (trueActionValues[i] > maxTrueValue) {
                maxTrueValue = trueActionValues[i];
                optimalArm = i;
            }
        }
        return optimalArm;
    }

    public int getNumArms() {
        return numArms;
    }

    @Override
    public String toString() {
        return "TenArmTestbed [numArms=" + numArms + ", trueActionValues=" + Arrays.toString(trueActionValues) + "]";
    }


}
