package pt.mleiria.rl.v1.mdc;

import java.util.*;

public class FrozenLakeMain {
    private static final Random RANDOM = new Random();

    public static void main(String[] args) {
        FrozenLakeEnvironment env = new FrozenLakeEnvironment();
        //QLearningAgent agent = new QLearningAgent(env.numStates, env.numActions);

        // --- Environment Setup Info ---
        System.out.println("--- Environment Setup ---");
        System.out.println("States: " + env.numStates());
        System.out.println("Actions: 0:Up, 1:Down, 2:Left, 3:Right -> " + env.numActions() + " actions");

        int episodes = 20000; // Number of episodes to train

        AgentResult qLearningResult = runAgent(env, episodes);
        // --- Results ---
        double[][] finalQTable = qLearningResult.qTable();
        System.out.println("\n--- Final Q-Table ---");
        printQTable(finalQTable);

        int[] policy = new int[env.numStates()];
        for (int i = 0; i < env.numStates(); i++) {
            policy[i] = findBestAction(finalQTable, i);
        }
        System.out.println("\n--- Optimal Policy (0:U, 1:D, 2:L, 3:R) ---");
        printPolicyGrid(policy);

        System.out.println("\n--- Visualized Policy ---");
        printVisualizedPolicy(policy, new HashSet<>(Arrays.asList(5, 7, 11, 12)), env.goalState());

    }

    public static AgentResult runAgent(MdcEnvironment env, int episodes) {

        double[][] qTable = new double[env.numStates()][env.numActions()];
        List<Integer> episodeRewards = new ArrayList<>();

        // Hyperparameters
        double alpha = 0.1;
        double gamma = 0.99;
        double epsilon = 1.0;
        double maxEpsilon = 1.0;
        double minEpsilon = 0.01;
        double decayRate = 0.001;

        for (int episode = 0; episode < episodes; episode++) {
            int state = env.reset(); // Reset to the starting state
            boolean done = false;
            int totalReward = 0;

            for (int step = 0; step < 100; step++) { // Limit steps to prevent infinite loops
                // Choose action using epsilon-greedy strategy
                int action = chooseEpsilonGreedyAction(qTable, state, epsilon, env.numActions());
                // Take action and observe the result
                StepResult result = env.step(state, action);

                state = result.nextState(); // Move to the next state
                // Get reward
                totalReward += result.reward();
                // Q-Learning (Off-policy). Update Q-value using the max Q-value of the next state
                qTable[state][action] += alpha * (result.reward() + gamma * findMaxQValue(qTable, result.nextState()) - qTable[state][action]);

                done = result.done(); // Check if the episode is done
                if( done) {
                    break; // Exit loop if episode is done
                }
            }
            episodeRewards.add(totalReward);
            // Decay epsilon
            epsilon = minEpsilon + (maxEpsilon - minEpsilon) * Math.exp(-decayRate * episode);
        }
        return new AgentResult(qTable, episodeRewards);
    }

    private static int chooseEpsilonGreedyAction(double[][] qTable, int state, double epsilon, int numActions) {
        if (RANDOM.nextDouble() < epsilon) {
            return RANDOM.nextInt(numActions); // Explore
        } else {
            return findBestAction(qTable, state); // Exploit
        }
    }



    private static int findBestAction(double[][] qTable, int state) {
        int bestAction = 0;
        double maxQ = Double.NEGATIVE_INFINITY;

        for (int action = 0; action < qTable[state].length; action++) {
            if (qTable[state][action] > maxQ) {
                maxQ = qTable[state][action];
                bestAction = action;
            }
        }
        return bestAction;
    }

    private static double findMaxQValue(double[][] qTable, int state) {
        double maxQ = Double.NEGATIVE_INFINITY;
        for (double qValue : qTable[state]) {
            if (qValue > maxQ) {
                maxQ = qValue;
            }
        }
        return maxQ;

    }

    // --- Helper printing functions ---
    public static void printQTable(double[][] qTable) {
        System.out.println("State\tUp\t\tDown\t\tLeft\t\tRight");
        System.out.println("----------------------------------------------------------");
        for (int i = 0; i < qTable.length; i++) {
            System.out.printf("%d\t", i);
            for (int j = 0; j < qTable[i].length; j++) {
                System.out.printf("%.2f\t\t", qTable[i][j]);
            }
            System.out.println();
        }
    }

    public static void printPolicyGrid(int[] policy) {
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                System.out.print(policy[r * 4 + c] + "\t");
            }
            System.out.println();
        }
    }

    public static void printVisualizedPolicy(int[] policy, Set<Integer> holes, int goalState) {
        String[] actionSymbols = {"↑", "↓", "←", "→"};
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                int stateIdx = r * 4 + c;
                if (holes.contains(stateIdx)) {
                    System.out.print(" H ");
                } else if (stateIdx == goalState) {
                    System.out.print(" G ");
                } else {
                    System.out.print(" " + actionSymbols[policy[stateIdx]] + " ");
                }
            }
            System.out.println();
        }
    }

}
