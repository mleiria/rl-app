package pt.mleiria.rl.v1;

import java.util.Set;

public class PrintUtils {


    // --- Helper printing functions ---
    public static void printQTable(double[][] qTable) {
        System.out.println("State\tUp\t\tDown\t\tLeft\t\tRight");
        System.out.println("----------------------------------------------------------");
        for (int i = 0; i < qTable.length; i++) {
            System.out.printf("%d\t", i);
            for (int j = 0; j < qTable[i].length; j++) {
                System.out.printf("%.2f\t\t", qTable[i][j]);
            }
            System.out.println();
        }
    }

    public static void printPolicyGrid(int[] policy) {
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                System.out.print(policy[r * 4 + c] + "\t");
            }
            System.out.println();
        }
    }

    public static void printVisualizedPolicy(int[] policy, Set<Integer> holes, int goalState) {
        String[] actionSymbols = {"↑", "↓", "←", "→"};
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                int stateIdx = r * 4 + c;
                if (holes.contains(stateIdx)) {
                    System.out.print(" H ");
                } else if (stateIdx == goalState) {
                    System.out.print(" G ");
                } else {
                    System.out.print(" " + actionSymbols[policy[stateIdx]] + " ");
                }
            }
            System.out.println();
        }
    }
}
