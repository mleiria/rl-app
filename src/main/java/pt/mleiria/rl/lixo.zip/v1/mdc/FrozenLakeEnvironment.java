package pt.mleiria.rl.v1.mdc;

import java.util.Set;

/**
 * A class to encapsulate the rules of the Frozen Lake environment.
 */
class FrozenLakeEnvironment implements MdcEnvironment {
    public final int nRows = 4; // Number of rows in the grid
    public final int nCols = 4; // Number of columns in the grid
    private final int numStates = nRows * nCols; // Total number of states in the grid
    private final int numActions = 4; // 0: Up, 1: Down, 2: Left, 3: Right

    private final int startState = 0; // Starting position (top-left corner of the grid)
    private final int goalState = 15; // Goal position (bottom-right corner of the grid)

    private final Set<Integer> holeStates; // Hole positions

    public FrozenLakeEnvironment(){
        // Define the hole states (5, 7, 11, 12)
        this.holeStates = Set.of(5, 7, 11, 12);
    }

    /**
     * Resets the environment to the starting state.
     *
     * @return The starting state.
     */
    public int reset() {
        return startState; // Reset to the starting state
    }

    public StepResult step(final int state, final int action) {
        int row = state / nCols;
        int col = state % nCols;

        // Apply action to get the next state
        if (action == 0) {
            row = Math.max(0, row - 1); // Up
        } else if (action == 1) {
            col = Math.min(nCols - 1, col + 1); // Right
        } else if (action == 2) {
            row = Math.min(nRows - 1, row + 1); // Down
        } else if (action == 3) {
            col = Math.max(0, col - 1); // Left
        }

        int nextState = row * nCols + col;
        int reward = -1; // Default reward for a normal move
        boolean done = false;
        if(holeStates.contains(nextState)) {
            reward = -10; // Penalty for falling into a hole
            nextState = startState; // Reset to start if falling into a hole
            done = true; // Episode ends if falling into a hole
        } else if(nextState == goalState) {
            done = true;
            reward = 10; // Reward for reaching the goal
        }
        return new StepResult(nextState, reward, done);
    }

    @Override
    public int numStates() {
        return numStates;
    }

    @Override
    public int numActions() {
        return numActions;
    }

    @Override
    public int goalState() {
        return goalState;
    }

}


