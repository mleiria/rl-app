package pt.mleiria.rl.v1.mdc;

import java.util.Set;

/**
 * A class to encapsulate the rules of the Cliff Walking environment.
 * The Cliff Walking environment is a grid world where an agent must navigate
 * from a starting position to a goal while avoiding falling off a cliff.
 * The grid is represented as follows:
 * 0   1   2   3   4   5   6   7   8   9  10  11
 * 12  13  14  15  16  17  18  19  20  21  22  23
 * 24  25  26  27  28  29  30  31  32  33  34  35
 * 36  37  38  39  40  41  42  43  44  45  46  47
 * S   C   C   C   C   C   C   C   C   C   C   G
 */
public class CliffWalkingEnvironment implements MdcEnvironment {

    public final int nRows = 4;
    public final int nCols = 12;
    public final int numStates = nRows * nCols;
    public final int numActions = 4; // 0: Up, 1: Down, 2: Left, 3: Right

    private final int startState = 36; // Starting position (3, 0)
    private final int goalState = 47; // Goal position (3, 11)
    private final Set<Integer> cliffStates;

    /**
     * The goal state is the bottom-right corner of the grid (state 47).
     * Cliff states are at row 3, columns 1 to 10 (states 37 to 46).
     * Rewards are:
     * - -100 for falling into a cliff state,
     * - -1 for all other moves.
     */
    public CliffWalkingEnvironment() {
        // Define the cliff states (row 3, columns 1 to 10)
        cliffStates = Set.of(37, 38, 39, 40, 41, 42, 43, 44, 45, 46);
    }

    public int reset() {
        return startState; // Reset to the starting state
    }

    public StepResult step(final int state, final int action) {
        int row = state / nCols;
        int col = state % nCols;

        // Apply action to get the next state
        if (action == 0) {
            row = Math.max(0, row - 1); // Up
        } else if (action == 1) {
            col = Math.min(nCols - 1, col + 1); // Right
        } else if (action == 2) {
            row = Math.min(nRows - 1, row + 1); // Down
        } else if (action == 3) {
            col = Math.max(0, col - 1); // Left
        }

        int nextState = row * nCols + col;
        int reward = -1; // Default reward for a normal move
        boolean done = false;
        if(cliffStates.contains(nextState)) {
            reward = -100; // Penalty for falling into a cliff
            nextState = startState; // Reset to start if falling into a cliff
            done = true; // Episode ends if falling into a cliff
        } else if(nextState == goalState) {
            done = true;
        }
        return new StepResult(nextState, reward, done);
    }

    @Override
    public int numStates() {
        return 0;
    }

    @Override
    public int numActions() {
        return 0;
    }

    @Override
    public int goalState() {
        return 0;
    }


}
