package pt.mleiria.rl.v1.mdc;

import java.util.Random;

public class QLearningAgent {
    private final double[][] qTable;
    private final Random random = new Random();

    // Hyperparameters
    private final double alpha; // Learning rate
    private final double gamma; // Discount factor
    private double epsilon;
    private final double minEpsilon;
    private final double maxEpsilon;
    private final double decayRate;

    /**
     * Constructs a QLearningAgent with a specified number of states and actions.
     *
     * @param numStates  the number of states in the environment
     * @param numActions the number of actions available to the agent
     */
    public QLearningAgent(int numStates, int numActions) {
        this.qTable = new double[numStates][numActions]; // Initializes to 0.0

        // Set hyperparameters
        this.alpha = 0.1;
        this.gamma = 0.99;
        this.epsilon = 1.0;
        this.maxEpsilon = 1.0;
        this.minEpsilon = 0.01;
        this.decayRate = 0.001;
    }

    /**
     * Chooses an action based on the epsilon-greedy strategy.
     *
     * @param state the current state of the environment
     * @return the action to be taken
     */
    public int chooseAction(int state) {
        if (random.nextDouble() < this.epsilon) {
            return random.nextInt(qTable[0].length); // Explore
        } else {
            return findBestAction(state); // Exploit
        }
    }

    /**
     * Updates the Q-table based on the agent's experience.
     *
     * @param state     the current state
     * @param action    the action taken
     * @param reward    the reward received
     * @param nextState the next state after taking the action
     */
    public void updateQTable(int state, int action, int reward, int nextState) {
        double oldQValue = qTable[state][action];
        double maxNextQ = findMaxQValue(nextState);
        double newQValue = oldQValue + alpha * (reward + gamma * maxNextQ - oldQValue);
        qTable[state][action] = newQValue;
    }

    /**
     * Decays the epsilon value to reduce exploration over time.
     *
     * @param episode the current episode number
     */
    public void decayEpsilon(int episode) {
        this.epsilon = minEpsilon + (maxEpsilon - minEpsilon) * Math.exp(-decayRate * episode);
    }

    /**
     * Returns the current Q-table.
     *
     * @return the Q-table
     */
    public double[][] getQTable() {
        return this.qTable;
    }

    /**
     * Finds the best action for a given state based on the Q-table.
     * Exploits the learned values to choose the action with the highest Q-value.
     *
     * @param state the current state
     * @return the index of the best action
     */
    public int findBestAction(int state) {
        int bestAction = 0;
        double maxQ = Double.NEGATIVE_INFINITY;
        for (int action = 0; action < qTable[state].length; action++) {
            if (qTable[state][action] > maxQ) {
                maxQ = qTable[state][action];
                bestAction = action;
            }
        }
        return bestAction;
    }

    // Helper method to find the max Q-value for a state (np.max)
    private double findMaxQValue(int state) {
        double maxQ = Double.NEGATIVE_INFINITY;
        for (double qVal : qTable[state]) {
            if (qVal > maxQ) {
                maxQ = qVal;
            }
        }
        return maxQ;
    }
}
