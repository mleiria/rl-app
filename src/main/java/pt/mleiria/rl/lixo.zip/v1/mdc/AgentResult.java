package pt.mleiria.rl.v1.mdc;

import java.util.List;

public record AgentResult(double[][] qTable, List<Integer> episodeRewards) {
}
