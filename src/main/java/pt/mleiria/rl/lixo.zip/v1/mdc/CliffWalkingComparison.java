package pt.mleiria.rl.v1.mdc;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CliffWalkingComparison {

    private static final Random RANDOM = new Random();

    public static AgentResult runAgent(String algorithm, CliffWalkingEnvironment env, int episodes) {

        double[][] qTable = new double[env.numStates][env.numActions];
        List<Integer> episodeRewards = new ArrayList<>();

        // Hyperparameters
        double alpha = 0.5; // Learning rate
        double gamma = 1.0; // Discount factor
        double epsilon = 0.1; // Exploration rate

        for (int episode = 0; episode < episodes; episode++) {
            int state = env.reset(); // Reset to the starting state
            boolean done = false;
            int totalReward = 0;

            // Chose first action
            int action = chooseEpsilonGreedyAction(qTable, state, epsilon, env.numActions);

            while (!done) {
                StepResult result = env.step(state, action);
                totalReward += result.reward();

                int nextAction = chooseEpsilonGreedyAction(qTable, result.nextState(), epsilon, env.numActions);

                double tdTarget;
                if ("q_learning".equalsIgnoreCase(algorithm)) {
                    // Q-Learning (Off-policy). Update Q-value using the max Q-value of the next state
                    tdTarget = result.reward() + gamma * findMaxQValue(qTable, result.nextState());
                } else{
                    // SARSA (On-policy). Update Q-value using the Q-value of the next action in the next state
                    tdTarget = result.reward() + gamma * qTable[result.nextState()][nextAction];
                }

                double tdError = tdTarget - qTable[state][action];
                qTable[state][action] += alpha * tdError; // Update Q-value
                state = result.nextState(); // Move to the next state
                action = nextAction; // Update action to the next action
                done = result.done(); // Check if the episode is done
            }
            episodeRewards.add(totalReward);
        }
        return new AgentResult(qTable, episodeRewards);
    }

    private static double findMaxQValue(double[][] qTable, int state) {
        double maxQ = Double.NEGATIVE_INFINITY;
        for (double qValue : qTable[state]) {
            if (qValue > maxQ) {
                maxQ = qValue;
            }
        }
        return maxQ;

    }

    private static int chooseEpsilonGreedyAction(double[][] qTable, int state, double epsilon, int numActions) {
        if (RANDOM.nextDouble() < epsilon) {
            return RANDOM.nextInt(numActions); // Explore
        } else {
            return findBestAction(qTable, state); // Exploit
        }
    }

    private static int findBestAction(double[][] qTable, int state) {
        int bestAction = 0;
        double maxQ = Double.NEGATIVE_INFINITY;

        for (int action = 0; action < qTable[state].length; action++) {
            if (qTable[state][action] > maxQ) {
                maxQ = qTable[state][action];
                bestAction = action;
            }
        }
        return bestAction;
    }

    /**
     * Prints the learned policy from a Q-table in a grid format.
     */
    public static void printPolicy(double[][] qTable, CliffWalkingEnvironment env) {
        String[] actionSymbols = {"↑", "→", "↓", "←"};
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < env.nRows; r++) {
            for (int c = 0; c < env.nCols; c++) {
                int stateIdx = r * env.nCols + c;
                if (stateIdx == 36) sb.append(" S ");
                else if (stateIdx == 47) sb.append(" G ");
                else if (stateIdx > 36 && stateIdx < 47) sb.append(" C ");
                else sb.append(" ").append(actionSymbols[findBestAction(qTable, stateIdx)]).append(" ");
            }
            sb.append("\n");
        }
        System.out.println(sb.toString());
    }

    /**
     * Calculates the average reward over the last n episodes.
     */
    public static double calculateAverageReward(List<Integer> rewards, int lastN) {
        if (rewards.size() < lastN) {
            return rewards.stream().mapToInt(Integer::intValue).average().orElse(0.0);
        }
        return rewards.subList(rewards.size() - lastN, rewards.size())
                .stream().mapToInt(Integer::intValue).average().orElse(0.0);
    }

    public static void main(String[] args) {
        CliffWalkingEnvironment env = new CliffWalkingEnvironment();
        int episodes = 500;

        // Run both agents
        AgentResult qLearningResult = runAgent("q_learning", env, episodes);
        AgentResult sarsaResult = runAgent("sarsa", env, episodes);

        // Print final policies
        System.out.println("--- Q-Learning (Optimal) Policy ---");
        printPolicy(qLearningResult.qTable(), env);

        System.out.println("\n--- SARSA (Safe) Policy ---");
        printPolicy(sarsaResult.qTable(), env);

        // Print performance summary
        System.out.println("\n--- Performance Summary ---");
        double qLearningAvgReward = calculateAverageReward(qLearningResult.episodeRewards(), 100);
        double sarsaAvgReward = calculateAverageReward(sarsaResult.episodeRewards(), 100);

        System.out.printf("Q-Learning Average Reward (last 100 episodes): %.2f\n", qLearningAvgReward);
        System.out.printf("SARSA Average Reward (last 100 episodes):      %.2f\n", sarsaAvgReward);
        System.out.println("\nNote: A higher (less negative) reward is better.");
        System.out.println("Q-Learning learns the risky, optimal path, leading to higher average rewards but more variance.");
        System.out.println("SARSA learns the safe path, leading to lower but more stable rewards.");
    }
}
