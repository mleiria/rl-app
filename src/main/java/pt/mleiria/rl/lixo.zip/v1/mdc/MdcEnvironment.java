package pt.mleiria.rl.v1.mdc;

public interface MdcEnvironment {

    int reset(); // Resets the environment to the starting state

    StepResult step(int state, int action); // Takes an action in the environment and returns the result

    int numStates(); // Returns the number of states in the environment

    int numActions(); // Returns the number of actions available in the environment

    int goalState(); // Returns the goal state of the environment
}
