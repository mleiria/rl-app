package pt.mleiria.rl.v1.mdc;

/**
 * Represents the result of taking a step in the environment.
 * This record encapsulates the next state, the reward received,
 * and whether the episode has ended (done).
 *
 * @param nextState
 * @param reward
 * @param done
 */
public record StepResult(int nextState, int reward, boolean done) {

}
