package pt.mleiria.rl;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.util.List;
import java.awt.Color;
import java.awt.Dimension;

public class MultipleLineChart extends JFrame {

    public MultipleLineChart(List<XYSeries> seriesList) {
        XYSeriesCollection dataset = new XYSeriesCollection();
        seriesList.forEach(dataset::addSeries);
        // Create the chart
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Multiple Line Chart",  // Chart title
                "X-Axis",               // X-axis label
                "Y-Axis",               // Y-axis label
                dataset,                // Dataset
                PlotOrientation.VERTICAL,
                true,                   // Show legend
                true,
                false
        );
        // Customize chart appearance
        chart.setBackgroundPaint(Color.white);

        // Display chart in a panel
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(600, 400));
        setContentPane(chartPanel);
    }


    public MultipleLineChart() {
        // Create first dataset (Series 1)
        XYSeries series1 = new XYSeries("Series 1");
        series1.add(1, 5);
        series1.add(2, 7);
        series1.add(3, 3);
        series1.add(4, 8);
        series1.add(5, 6);

        // Create second dataset (Series 2)
        XYSeries series2 = new XYSeries("Series 2");
        series2.add(1, 3);
        series2.add(2, 5);
        series2.add(3, 6);
        series2.add(4, 2);
        series2.add(5, 7);

        // Combine datasets
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series1);
        dataset.addSeries(series2);

        // Create the chart
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Multiple Line Chart",  // Chart title
                "X-Axis",               // X-axis label
                "Y-Axis",               // Y-axis label
                dataset,                // Dataset
                PlotOrientation.VERTICAL,
                true,                   // Show legend
                true,
                false
        );

        // Customize chart appearance
        chart.setBackgroundPaint(Color.white);

        // Display chart in a panel
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(600, 400));
        setContentPane(chartPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MultipleLineChart example = new MultipleLineChart();
            example.setSize(800, 600);
            example.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            example.setVisible(true);
        });
    }
}
