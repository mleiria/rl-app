package pt.mleiria.rl;

public interface Agent {

    int chooseAction();

    void updateEstimates(int chosenArm, double reward);
}
