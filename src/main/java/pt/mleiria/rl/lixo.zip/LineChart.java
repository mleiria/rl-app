package pt.mleiria.rl;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.util.List;

public class LineChart {

    private String title;
    private String xLabel;
    private String yLabel;
    private List<XYSeries> series;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getxLabel() {
        return xLabel;
    }

    public void setxLabel(String xLabel) {
        this.xLabel = xLabel;
    }

    public String getyLabel() {
        return yLabel;
    }

    public void setyLabel(String yLabel) {
        this.yLabel = yLabel;
    }

    public List<XYSeries> getSeries() {
        return series;
    }

    public void setSeries(List<XYSeries> series) {
        this.series = series;
    }

    public JFreeChart createDataset(){
        XYSeriesCollection dataset = new XYSeriesCollection();
        series.forEach(dataset::addSeries);

        // Create the chart
        JFreeChart chart = ChartFactory.createXYLineChart(
                title,  // Chart title
                xLabel,               // X-axis label
                yLabel,               // Y-axis label
                dataset,                // Dataset
                PlotOrientation.VERTICAL,
                true,                   // Show legend
                true,
                false
        );

        return chart;
    }


    public static final class LineChartBuilder {
        private String title;
        private String xLabel;
        private String yLabel;
        private List<XYSeries> series;

        private LineChartBuilder() {
        }

        public static LineChartBuilder aLineChart() {
            return new LineChartBuilder();
        }

        public LineChartBuilder withTitle(String title) {
            this.title = title;
            return this;
        }

        public LineChartBuilder withXLabel(String xLabel) {
            this.xLabel = xLabel;
            return this;
        }

        public LineChartBuilder withYLabel(String yLabel) {
            this.yLabel = yLabel;
            return this;
        }

        public LineChartBuilder withSeries(List<XYSeries> series) {
            this.series = series;
            return this;
        }

        public LineChart build() {
            LineChart lineChart = new LineChart();
            lineChart.setTitle(title);
            lineChart.setSeries(series);
            lineChart.xLabel = this.xLabel;
            lineChart.yLabel = this.yLabel;
            return lineChart;
        }
    }
}
